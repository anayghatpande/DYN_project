Scheduling.zip contains the python code (schedule.py) and CSV.zip contains data files. 
Unzip the CSV files in desired location and change the path accordingly in the scheduling.py file. 
Scheduling.py code file can be executed using Anaconda (IDE for python with version 3.7 and pyomo package version 5.6.9). 
Make sure you have Gurobi license (version 9.0) installed.
Follow the instructions given in the readme file inside CSV.zip file.
