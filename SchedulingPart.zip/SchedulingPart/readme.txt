Scheduling.zip contains the python code and CSV.zip contains data files. 
Unzip the CSV files in desired location and change the path accordingly in the scheduling.py file. 
Scheduling.py code file can be executed using any IDE for python. 
Make sure Gurobi license is present.